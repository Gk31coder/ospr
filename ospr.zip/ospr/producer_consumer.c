// Thread synchronization using counting semaphores. Application to demonstrate Producer-Consumer Problem

#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>

#define BUFFER_SIZE 10

// Shared buffer
char buff[BUFFER_SIZE];

// Semaphores
sem_t mutex, empty, full;

/* Producer function */
void* produce(void* arg)
{
    int i;
    printf("\nInside Producer");
    for (i = 0; i < BUFFER_SIZE; i++)
    {
        sem_wait(&empty);  // Wait if buffer is full
        sem_wait(&mutex);  // Enter critical section

        buff[i] = i;       // Produce item
        printf("\nProduced Item : %d", buff[i]);

        sem_post(&mutex);  // Exit critical section
        sem_post(&full);   // Increment count of full slots

        sleep(1);          // Simulate production time
    }
    pthread_exit("produce\n");
}

/* Consumer function */
void* consumer(void* arg)
{
    int j;
    printf("\nInside Consumer");
    for (j = 0; j < BUFFER_SIZE; j++)
    {
        sem_wait(&full);   // Wait if buffer is empty
        sem_wait(&mutex);  // Enter critical section

        int item = buff[j];   // Consume item
        printf("\nConsumed Item : %d", item);

        sem_post(&mutex);  // Exit critical section
        sem_post(&empty);  // Increment count of empty slots

        sleep(1);          // Simulate consumption time
    }
    pthread_exit("consumer\n");
}

int main()
{
    pthread_t tid1, tid2;
    void* status;

    // Initialize semaphores
    sem_init(&empty, 0, BUFFER_SIZE);
    sem_init(&full, 0, 0);
    sem_init(&mutex, 0, 1);

    // Create threads
    pthread_create(&tid1, NULL, produce, NULL);
    pthread_create(&tid2, NULL, consumer, NULL);

    // Wait for threads to finish
    pthread_join(tid1, &status);
    printf("\nThe exited status %s\n", (char*)status);

    pthread_join(tid2, &status);
    printf("\nThe exited status %s\n", (char*)status);

    // Destroy semaphores
    sem_destroy(&empty);
    sem_destroy(&full);
    sem_destroy(&mutex);

    return 0;
}
/*
ayulap@gayulap-VirtualBox:~/Desktop$ gcc producer_consumer.c
gayulap@gayulap-VirtualBox:~/Desktop$ ./a.out

Inside Producer
Inside Consumer
Produced Item : 0
Consumed Item : 0
Produced Item : 1
Consumed Item : 1
Produced Item : 2
Consumed Item : 2
Produced Item : 3
Consumed Item : 3
Produced Item : 4
Consumed Item : 4
Produced Item : 5
Consumed Item : 5
Produced Item : 6
Consumed Item : 6
Produced Item : 7
Consumed Item : 7
Produced Item : 8
Consumed Item : 8
Produced Item : 9
Consumed Item : 9
The exited status produce


The exited status consumer
*/

